<?php 
define('PLUGIN_DIR', plugin_dir_path(__DIR__));
define('CLAIMS_DIR', PLUGIN_DIR."public/dist");
define('PLUGIN_URL', plugin_dir_url(__DIR__));
define('CLAIMS_URL', PLUGIN_URL."public/dist");


define('RECLAIM_MODULE_SCRIPT', "RECLAIM_MODULE_SCRIPT");
define('RECLAIM_SCRIPT', "RECLAIM_SCRIPT");

define('RECLAIM_MODULEPRELOAD_STYLE', "RECLAIM_MODULEPRELOAD_STYLE");
define('RECLAIM_STYLE', "RECLAIM_STYLE");
define('INCORRECT_SHORTCODE', "Incorrect Shortcode");
