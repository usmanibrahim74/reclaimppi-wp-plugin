import { createApp } from "vue";
import App from "./App.vue";
import "./app.scss?inline";

createApp(App).mount("#app");

