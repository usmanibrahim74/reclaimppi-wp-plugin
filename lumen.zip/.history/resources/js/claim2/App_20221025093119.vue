<script setup>
import { reactive, onMounted, ref } from "vue";
import axios from "axios";
import Step from "../components/Step.vue"

let state = reactive({});
onMounted(() => {});
</script>

  <template>
  <div class="block relative w-[100vw] -translate-x-1/2 left-1/2 p-2">
    <div class="flex justify-center items-center w-full mx-auto">
      <div class="max-w-[100px]">
        <img class="w-100"
          src="https://www.synergidigital.com/wp-content/uploads/synergi-round-logo.png"
          alt="company logo"
        />
      </div>
    </div>
    <div class="max-w-[900px] mx-auto">
      <div class="px-[100px] mx-auto ">
        <div class="flex items-center mx-auto my-40">
          <Step title="PPI Claim Detail" :step="1" :current_step="state.step" />
          <div
            class="sprogress-bar__step"
            :class="{
              'sprogress-bar__step--complete': state.step >= 3,
              'sprogress-bar__step--active': state.step >= 2,
            }"
          >
            <p
              class="sprogress-bar__step__text"
              :class="{ 'sprogress-bar__step__text--active': state.step >= 2 }"
            >
              About You
            </p>
            <div class="sprogress-bar__step-number">2</div>
          </div>
          <div
            class="sprogress-bar__step"
            :class="{
              'sprogress-bar__step--complete': state.step >= 4,
              'sprogress-bar__step--active': state.step >= 3,
            }"
          >
            <p
              class="sprogress-bar__step__text"
              :class="{ 'sprogress-bar__step__text--active': state.step >= 3 }"
            >
              Contact Details
            </p>
            <div class="sprogress-bar__step-number">3</div>
          </div>
          <div
            class="sprogress-bar__step"
            :class="{
              'sprogress-bar__step--complete': state.step > 4,
              'sprogress-bar__step--active': state.step >= 4,
            }"
          >
            <p
              class="sprogress-bar__step__text"
              :class="{ 'sprogress-bar__step__text--active': state.step >= 4 }"
            >
              Start Claim
            </p>
            <div class="sprogress-bar__step-number">4</div>
          </div>
        </div>
        <div class="swizard__step" v-if="state.step == 1">
          <div class="swizard__title">
            <p class="swizard__title__p text-center">
              Please enter your PPI Claim details
            </p>
            <hr class="swizard__title__line" />
          </div>
          <div class="swizard__radio">
            <p>
              Were you required to complete a Self-Assessment the year you got
              your PPI refund?
            </p>
            <div class="swizard__radio__items">
              <div class="swizard__radio__items__item">
                <input id="radio1" type="radio" name="year" />
                <label for="radio1"><span>Yes </span></label>
              </div>
              <div class="swizard__radio__items__item">
                <input id="radio2" type="radio" name="year" />
                <label for="radio2">No</label>
              </div>
            </div>
          </div>
          <div class="swizard__title">
            <p class="swizard__title__p">
              Please provide us with the TOTAL amount you received for your PPI
              refunds in the relevant tax years below
            </p>
          </div>
          <div class="swizard__years">
            <div class="swizard__years__items">
              <p>Apr 2018 - Mar 2019</p>
              <div class="swizard__years__items__item">
                <span class="swizard__years__items__item__left-icon">£</span>
                <input type="text" class="swizard__years__items__item__box" />
                <span class="swizard__years__items__item__right-icon"
                  ><IconInfo
                /></span>
              </div>
            </div>
            <div class="swizard__years__items">
              <p>Apr 2019 - Mar 2020</p>
              <div class="swizard__years__items__item">
                <span class="swizard__years__items__item__left-icon">£</span>
                <input type="text" class="swizard__years__items__item__box" />
                <span class="swizard__years__items__item__right-icon"
                  ><IconInfo
                /></span>
              </div>
            </div>
            <div class="swizard__years__items">
              <p>Apr 2020 - Mar 2021</p>
              <div class="swizard__years__items__item">
                <span class="swizard__years__items__item__left-icon">£</span>
                <input type="text" class="swizard__years__items__item__box" />
                <span class="swizard__years__items__item__right-icon"
                  ><IconInfo
                /></span>
              </div>
            </div>
            <div class="swizard__years__items">
              <p>Apr 2021 - Mar 2022</p>
              <div class="swizard__years__items__item">
                <span class="swizard__years__items__item__left-icon">£</span>
                <input type="text" class="swizard__years__items__item__box" />
                <span class="swizard__years__items__item__right-icon"
                  ><IconInfo
                /></span>
              </div>
            </div>
          </div>
          <div class="swizard__radio">
            <p>
              Were you earning less than £50,000.00 a year at the time you
              received your PPI refund?
            </p>
            <div class="swizard__radio__items">
              <div class="swizard__radio__items__item">
                <input id="amount1" type="radio" name="amount" />
                <label for="amount1">Yes</label>
              </div>
              <div class="swizard__radio__items__item">
                <input id="amount2" type="radio" name="amount" />
                <label for="amount2">No</label>
              </div>
            </div>
          </div>
          <div class="swizard__input">
            <p>National insurance (NI) Number</p>
            <div class="swizard__input__item">
              <input class="swizard__input__item__box" />
              <span class="swizard__input__item__right-icon"><IconInfo /></span>
            </div>
          </div>
          <div class="swizard__sign__checkbox">
            <input id="agreed" type="checkbox" :value="1" />
            <label for="agreed">Can't remember (Provide it later) </label>
          </div>
          <div class="swizard__submit">
            <button
              type="button"
              class="sbutton sbutton__primary sbutton--active"
              @click="stepForward"
            >
              Continue <span class="sbutton__primary__icon"><IconNext /></span>
            </button>
          </div>
        </div>
        <div class="swizard__step" v-if="state.step == 2">
          <div class="swizard__title">
            <p class="swizard__title__p text-center">
              Please complete your details below to start your claim
            </p>
            <hr class="swizard__title__line" />
          </div>
          <div class="swizard__about">
            <div class="swizard__input swizard__about__item">
              <p>Title</p>
              <div class="swizard__input__item">
                <select class="swizard__input__item__box">
                  <option value="null">Mr</option>
                </select>
                <span class="swizard__input__item__right-icon"
                  ><IconSelect
                /></span>
              </div>
            </div>
            <div class="swizard__input swizard__about__item">
              <p>First Name</p>
              <div class="swizard__input__item">
                <input class="swizard__input__item__box" />
              </div>
            </div>
            <div class="swizard__input swizard__about__item">
              <p>Last Name</p>
              <div class="swizard__input__item">
                <input class="swizard__input__item__box" />
              </div>
            </div>
          </div>
          <p>DOB</p>
          <div class="swizard__about">
            <div class="swizard__input swizard__about__item">
              <div class="swizard__input__item">
                <select class="swizard__input__item__box">
                  <option value="null">Day</option>
                </select>
                <span class="swizard__input__item__right-icon"
                  ><IconSelect
                /></span>
              </div>
            </div>
            <div class="swizard__input swizard__about__item">
              <div class="swizard__input__item">
                <select class="swizard__input__item__box">
                  <option value="null">Month</option>
                </select>
                <span class="swizard__input__item__right-icon"
                  ><IconSelect
                /></span>
              </div>
            </div>
            <div class="swizard__input swizard__about__item">
              <div class="swizard__input__item">
                <select class="swizard__input__item__box">
                  <option value="null">Year</option>
                </select>
                <span class="swizard__input__item__right-icon"
                  ><IconSelect
                /></span>
              </div>
            </div>
          </div>
          <div class="swizard__submit">
            <button
              type="button"
              class="sbutton sbutton__primary sbutton--active"
              @click="stepForward"
            >
              Continue <span class="sbutton__primary__icon"><IconNext /></span>
            </button>
            <button
              type="button"
              @click="stepBack"
              class="sbutton sbutton__back"
            >
              <span class="sbutton__primary__back"><IconPrevious /></span>Back
            </button>
          </div>
        </div>
        <div class="swizard__step" v-if="state.step == 3">
          <div class="swizard__title">
            <p class="swizard__title__p text-center">
              Enter your contact details to claim your tax back
            </p>
            <hr class="swizard__title__line" />
          </div>
          <div class="swizard__input">
            <p>Email</p>
            <div class="swizard__input__item">
              <input class="swizard__input__item__box" />
            </div>
          </div>
          <div class="swizard__input">
            <p>Phone Number</p>
            <div class="swizard__input__item">
              <input class="swizard__input__item__box" />
            </div>
          </div>
          <div class="swizard__input">
            <p>Address</p>
            <div class="swizard__input__item">
              <input class="swizard__input__item__box" />
            </div>
          </div>
          <div class="swizard__input">
            <p>Postcode</p>
            <div class="swizard__input__item">
              <input class="swizard__input__item__box" />
            </div>
          </div>
          <div class="swizard__sign__checkbox">
            <input id="agreed" type="checkbox" :value="1" />
            <label for="agreed"
              ><small
                >I agree for Reclaim My PPI Tax to contact me with regards to
                any tax rebate purposes.</small
              >
            </label>
          </div>

          <div class="swizard__submit">
            <button
              type="button"
              class="sbutton sbutton__primary sbutton--active"
              @click="stepForward"
            >
              Continue <span class="sbutton__primary__icon"><IconNext /></span>
            </button>
            <button
              type="button"
              @click="stepBack"
              class="sbutton sbutton__back"
            >
              <span class="sbutton__primary__back"><IconPrevious /></span> Back
            </button>
          </div>
        </div>
        <div class="swizard__step" v-if="state.step == 4">
          <div class="swizard__claim swizard__title">
            <h3>Great News!</h3>
            <p class="swizard__claim__congrat">
              <span class="swizard__claim__success">Congratulations, </span> You
              100% meet the criteria
            </p>
            <p class="swizard__claim__time">
              Our customers get money back in 6 Weeks!
            </p>
            <hr class="swizard__title__line" />
          </div>
          <div class="swizard__claim__message">
            <p>
              Signing below agrees you into our
              <span class="swizard__claim__message__terms"
                >terms and conditions</span
              >
              and our NO WIN NO FEE services.
            </p>
          </div>
          <div class="swizard__input">
            <p>Do you have a referral code? (optional)</p>
            <div class="swizard__input__item">
              <input class="swizard__input__item__box" />
            </div>
          </div>
          <div class="swizard__input">
            <p>Please draw your signature below in the green box.</p>
            <div class="swizard__input__item">
              <textarea class="swizard__input__item__box" rows="5"></textarea>
            </div>
          </div>
          <small>Clear Signature</small>
          <div class="swizard__submit">
            <button
              type="button"
              class="sbutton sbutton__primary sbutton--active"
            >
              Start Your Claim
            </button>
            <button
              type="button"
              @click="stepBack"
              class="sbutton sbutton__back"
            >
              <span class="sbutton__primary__back"><IconPrevious /></span> Back
            </button>
          </div>
        </div>
        <div class="swizard__error">
          <ul>
            <li v-for="(error, i) in state.errors" :key="i">{{ error }}</li>
          </ul>
        </div>
      </div>
    </div>
    <!-- <Footer :donations="state.donations" /> -->
  </div>
</template>