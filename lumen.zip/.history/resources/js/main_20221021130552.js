import { createApp } from "vue";
import App from "./claims/claim2/App.vue";
import "./../scss/app.scss";

createApp(App).mount("#app");

