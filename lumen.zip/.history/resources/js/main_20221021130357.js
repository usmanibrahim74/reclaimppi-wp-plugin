import { createApp } from "vue";
import App from "./claims/claim1/App.vue";
import "./../scss/app.scss";

createApp(App).mount("#app");

