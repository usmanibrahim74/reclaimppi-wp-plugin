<?php
/**
* Plugin Name: ReclaimPPI
* Description: ReclaimPPI.
* Version: 0.1
* Author: SynergiDigital
* Author URI: http://synergidigital.com
**/

include_once('wp/constants.php');
include_once('wp/helpers.php');
include_once('wp/filters.php');
include_once('wp/shortcodes.php');









