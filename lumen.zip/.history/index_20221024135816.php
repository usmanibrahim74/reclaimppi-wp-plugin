<?php
/**
* Plugin Name: ReclaimPPI
* Description: ReclaimPPI.
* Version: 0.1
* Author: SynergiDigital
* Author URI: http://synergidigital.com
**/

add_shortcode('reclaimppi_claim_1','reclaimppi_claim_1');
function reclaimppi_claim_1($arr){
    var_dump($arr);
}