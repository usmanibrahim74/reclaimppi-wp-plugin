<template>
    <div class="flex justify-center items-center w-full mx-auto">
      <div class="max-w-[100px]">
        <img class="w-100"
          src="https://www.synergidigital.com/wp-content/uploads/synergi-round-logo.png"
          alt="company logo"
        />
      </div>
    </div>
</template>