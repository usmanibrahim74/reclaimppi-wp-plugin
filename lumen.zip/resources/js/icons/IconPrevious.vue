<template>

<svg width="12" height="14" viewBox="0 0 12 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M8.15658 14L11.0298 11.7814L5.52361 7.1799L11.0298 2.58578L8.15658 0.367145L1.3247 6.07413L-0.000706673 7.17986L1.3247 8.29277L8.15658 14Z" fill="#616A7A"/>
</svg>

</template>