<template>
<svg width="12" height="14" viewBox="0 0 12 14" fill="none" xmlns="http://www.w3.org/2000/svg">
<path d="M2.8732 0.224609L0 2.38838L5.50617 6.87605L0 11.3566L2.8732 13.5203L9.70509 7.95447L11.0305 6.87608L9.70509 5.7907L2.8732 0.224609Z" fill="white"/>
</svg>
</template>